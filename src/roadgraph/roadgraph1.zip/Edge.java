package roadgraph;

import geography.GeographicPoint;

public class Edge {
    private GeographicPoint from;
    private GeographicPoint to;
    private String roadName;
    private String roadType;
    private double length;
    public Edge (GeographicPoint from, GeographicPoint to, String roadName,
          String roadType, double length){
        this.from = from;
        this.to = to;
        this.roadName = roadName;
        this.roadType = roadType;
        this.length = length;
    }

    public GeographicPoint getToNode(){
        return this.to;
    }

    public String toString(){
        //return("from: " + this.from + " --> to: " + this.to + " (RoadName: " + this.roadName+" , length: " + (int)this.length +")");
        return(" / node: " + this.to );
    }
}
